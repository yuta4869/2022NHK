﻿
JP   CADファイルのリクエスト：Your download from the 08.10.2020 on PARTcommunity/PARTserver:

       お客様へ

       3D CAD download portal PARTcommunity/PARTserver にリクエストされたCADデータをお送りします。添付ファイルをご確認ください。powered by CADENAS

       
	   
       STEP, SCS0812CP3, SCS0812CP3.stp

       ご利用方法：

       
       添付ファイルは、圧縮ファイルです ("ZIP")。
       ファイルを解凍するには、解凍ソフトが必要です。 

       解凍ソフトをインストールしていない場合は、以下からダウンロードできます：
       PKZip® (http://www.pkware.com) または WinZip® (http://www.winzip.com)

       ご利用条件は： http://www.cadenas.de/jp/terms-of-use-3d-cad-models
       
                   

       
       Best regards

       CADENAS GmbH
       support@cadenas.de




       >> Free APP for 3D CAD models <<
       
       スマートフォンやタブレットPCで 3D CAD models へアクセス 
       
       無料ダウンロードはこちらから： http://www.cadenas.de/en/app-store




       >> PARTcommunity - エンジニアのためのネットワークと情報のプラットフォーム <<
       
       ■ コンポーネントの使用例やアイデア 
       ■ エンジニア同士の情報交換

       ディスカッションへの参加は： http://www.partcommunity.com
       

       
